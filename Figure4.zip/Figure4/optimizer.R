
proc_start<-proc.time()

options(warn=1)

library(optparse)
#library(optparse, lib.loc = "/home/mohammadreza.samieegohar/R_packages")

isWindows<-Sys.info()[["sysname"]]=="Windows"

#--- specify command line arguments
parser<-OptionParser()
parser<-add_option(parser, c("-d", "--drug"), default="viruscytokines",type="character", help="Drug name [required]")
parser<-add_option(parser, c("-o", "--opioids"), default="viruscytokines",type="character", help="opioids name [required]")
parser<-add_option(parser, c("-i", "--sample"), default="0", help="Bootstrap sample number, range, and/or list of samples to be fitted [default 0 fits to original data]")
parser<-add_option(parser, c("-e", "--ERR"), default="1", help="xxxrap sample number, range, and/or list of samples to be fitted [default 0 fits to original data]")
parser<-add_option(parser, c("-s", "--seed"), default=100, type="integer", help="Random seed [default 100]")
parser<-add_option(parser, c("-c", "--cores"), default=1, type="integer", help="Number of cores to use during fitting [default 1]")
parser<-add_option(parser, c("-f", "--forking"), default=FALSE, action="store_true", help="Flag to turn on forking for parallelization (not supported in Windows)")
parser<-add_option(parser, c("-l", "--lambda"), default=30,type="integer", help="Population size to use for CMA-ES [default 4+floor(3*log(N))]")
parser<-add_option(parser, c("-m", "--maxiter"), default=200,type="integer", help="Maximum number of generations for CMA-ES [default 100*N^2]")
parser<-add_option(parser, c("-t", "--tol"), default=.1,type="double", help="Stopping tolerance for CMA-ES [default 0.5e-12]")

args<-parse_args(parser)
source("models/deWrapper.R")
#--- load libraries
library(cmaes)
library(parallel)
library(deSolve)
#library(deSolveV, lib.loc = "/home/mohammadreza.samieegohar/Coviddesolve")

print(sessionInfo())

#--- required argument
#if(is.null(args$drug)) stop("Missing drug argument!")
#drug<-args$drug



#--- optional arguments
seednum<-args$seed
cores<-args$cores
usefork<-args$forking
POP_SIZE<-args$lambda
MAX_GENERATION<-args$maxiter
STOPTOL<-args$tol

if(usefork && isWindows){
	print("Windows system detected! Forking not supported, using sockets instead...")
	usefork<-FALSE
}

# cmaes hyperparameters
ctl_list<-list(vectorized=TRUE)
if(!is.null(POP_SIZE)){
	print(sprintf("Using population size: %g",POP_SIZE))
	ctl_list[["lambda"]]<-POP_SIZE
}
if(!is.null(MAX_GENERATION)){
	print(sprintf("Using number of generations: %g",MAX_GENERATION))
	ctl_list[["maxit"]]<-MAX_GENERATION
}
if(!is.null(STOPTOL)){
	print(sprintf("Using stopping tolerance: %g",STOPTOL))
	ctl_list[["stop.tolx"]]<-STOPTOL
}
#--- setup serial or parallel evaluation
setupfile<-"setup_hERG_fitting.R"
usesocket<-FALSE
if(cores>1){
	if(usefork){
		lapplyfun<-function(X, FUN) mclapply(X, FUN, mc.cores=cores, mc.preschedule=FALSE)
	}else{
		cl<-makeCluster(cores)
		invisible(clusterEvalQ(cl,library(deSolve)))
		clusterExport(cl,c("setupfile","drug","isWindows"))
		
		lapplyfun<-function(X, FUN) clusterApply(cl, X, FUN)
		usesocket<-TRUE
	}
}else{
	lapplyfun<-lapply
}
