in this revision:
noe we are usiong 1 thresholds again by having Co2 in background