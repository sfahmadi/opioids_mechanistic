#include <R.h>
#include <Rinternals.h>
#include <Rdefines.h>
#include <R_ext/Rdynload.h>
#include <time.h>
static double parms[90];
#define F parms[0]
#define kin parms[1]
#define kout parms[2]
#define ktr parms[3]
#define kout2 parms[4]
#define k1 parms[5]
#define k2 parms[6]
#define k12 parms[7]
#define k13 parms[8]
#define k21 parms[9]
#define k31 parms[10]
#define A1 parms[11]
#define B1 parms[12]
#define n parms[13]
#define A2 parms[14]
#define B2 parms[15]
#define n2 parms[16]
#define V1 parms[17]
#define Mmass parms[18]
#define V_A parms[19]
#define P_I_co2 parms[20]
#define P_I_o2 parms[21]
#define lumbda parms[22]
#define Q1 parms[23]
#define s1 parms[24]
#define z parms[25]
#define alpha_co2 parms[26]
#define C_B_hco3 parms[27]
#define C_T_hco3 parms[28]
#define alpha_o2 parms[29]
#define K1 parms[30]
#define K2 parms[31]
#define a1 parms[32]
#define a2 parms[33]
#define alpha1 parms[34]
#define beta1 parms[35]
#define alpha2 parms[36]
#define beta2 parms[37]
#define Z parms[38]
#define C1Spencer parms[39]
#define C2Spencer parms[40]
#define Qb0 parms[41]
#define Qt0 parms[42]
#define rou parms[43]
#define V_B parms[44]
#define M_B_co2 parms[45]
#define M_B_o2_0 parms[46]
#define V_T parms[47]
#define M_T_co2 parms[48]
#define M_T_o2_0 parms[49]
#define P3 parms[50]
#define B parms[51]
#define P1 parms[52]
#define Bmax parms[53]
#define P2 parms[54]
#define K0 parms[55]
#define Aco2 parms[56]
#define Bco2 parms[57]
#define Cco2 parms[58]
#define Dco2 parms[59]
#define P_a_co2_0 parms[60]
#define tau_co2 parms[61]
#define c1o2 parms[62]
#define c2o2 parms[63]
#define P_a_o2_0 parms[64]
#define tau_o2 parms[65]
#define K_Dp parms[66]
#define K_Dc parms[67]
#define K_fpc parms[68]
#define Bp parms [69]
#define f_pc_max parms[70]
#define f_pc_min parms[71]
#define f_pc_0 parms[72]
#define P_a_o2_c parms[73]
#define K_pc parms[74]
#define tau_Dp parms[75]
#define tau_Dc parms[76]
#define G_Dp parms[77]
#define G_Dc parms[78]
#define P_B_co2_0 parms[79]
#define theta_Hmin parms[80]
#define Gh parms[81]
#define P_B_o2_0 parms[82]
#define tau_h parms[83]
#define theta_Hmax parms[84]
#define W parms[85]
#define fL parms[86]
#define fN parms[87]
#define timeout parms[88]
#define starttime parms[89]


#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; });
void lagvalue(double *T, int *nr, int N, double *yout) {
static void(*fun)(double*, int*, int, double*) = NULL;
if(fun==NULL)
fun =  (void(*)(double*, int*, int, double*))R_GetCCallable("deSolve", "lagvalue");
return fun(T, nr, N, yout);
}
void lagderiv(double *T, int *nr, int N, double *yout) {
static void(*fun)(double*, int*, int, double*) = NULL;
if (fun == NULL)
fun =  (void(*)(double*, int*, int, double*))R_GetCCallable("deSolve", "lagvalue");
return fun(T, nr, N, yout);
}

void initmod(void (* odeparms)(int *, double *)){
int N=90;
odeparms(&N, parms);}


 double* calc_intermediate(double *y){



   /* local variable declaration */
	 static double johncevtor[23];




if (y[13]<0) /*  y[13] = C_B_co2 */
y[13]=0;

  double i_C_B_co2_dissolved = y[13] - C_B_hco3;

  double i_P_B_co2= i_C_B_co2_dissolved/alpha_co2;

/*  * P_B_co2 = C_B_co2_dissolved/alpha_co2; */

  double i_P_Vb_co2 =i_P_B_co2;

if (y[14]<0) /* y[14] = C_B_o2 */
y[14]=0;

double i_P_B_o2 = y[14]/alpha_o2;

double i_P_Vb_o2 = i_P_B_o2;

 double F2_1 =i_P_Vb_co2*(1+beta2*i_P_Vb_o2)/(K2*(1+alpha2*i_P_Vb_o2));
 double i_C_Vb_co2 = Z*C2Spencer*pow(F2_1,1.00/a2)/(1+pow(F2_1,1.00/a2));
 double F1_1 = i_P_Vb_o2*(1+beta1*i_P_Vb_co2)/(K1*(1+alpha1*i_P_Vb_co2));
 double i_C_Vb_o2 = Z*C1Spencer*pow(F1_1,1.00/a1)/(1+pow(F1_1,1.00/a1));

if (y[15]<0) /* y[15] = C_T_co2 */
y[15] = 0;

 double i_C_T_co2_dissolved = y[15] - C_T_hco3;
 double i_P_T_co2 = i_C_T_co2_dissolved/alpha_co2;
 double i_P_Vt_co2 = i_P_T_co2;

if(y[16]<0) /*y[16] = C_T_o2 */
y[16] = 0;
double i_P_T_o2=y[16]/alpha_o2;
double i_P_Vt_o2=i_P_T_o2;
 double F2_2 = i_P_Vt_co2*(1+beta2*i_P_Vt_o2)/(K2*(1+alpha2*i_P_Vt_o2));
 double i_C_Vt_co2 = Z*C2Spencer*pow(F2_2,1.00/a2)/(1+pow(F2_2,1.00/a2));
 double F1_2 = i_P_Vt_o2*(1+beta1*i_P_Vt_co2)/(K1*(1+alpha1*i_P_Vt_co2));
 double i_C_Vt_o2 = Z*C1Spencer*pow(F1_2,1.00/a1)/(1+pow(F1_2,1.00/a1));

if (y[11]<0) /* y[11] = P_A_co2 */
y[11]=0;
 double i_P_e_co2=y[11];


//if(y[12]<0) /* y[12] = P_A_o2 */
//y[12]=0;
 double i_P_e_o2=y[12];

 double F2_3 = i_P_e_co2*(1+beta2*i_P_e_o2)/(K2*(1+alpha2*i_P_e_o2));
 double i_C_e_co2 = Z*C2Spencer*pow(F2_3,1.00/a2)/(1+pow(F2_3,1.00/a2));
 double F1_3 = i_P_e_o2*(1+beta1*i_P_e_co2)/(K1*(1+alpha1*i_P_e_co2));
 double i_C_e_o2 = Z*C1Spencer*pow(F1_3,1.00/a1)/(1+pow(F1_3,1.00/a1));

/* Local bloodflow brain & tissue */

/* * yo2 = 0;
 * yco2 = 0;
*/
 double i_Qb = Qb0*(1+y[18]+y[19]);
// printf("%f", i_Qb);
 double i_Qt = Qt0*(1+rou*y[19]);

/*Mixed venous */

 double i_C_V_co2 = (i_Qb*i_C_Vb_co2+i_Qt*(i_C_Vt_co2))/(i_Qb+i_Qt);
 double i_C_V_o2 = (i_Qb*i_C_Vb_o2+i_Qt*(i_C_Vt_o2))/(i_Qb+i_Qt);
 double i_Q = i_Qb + i_Qt;

/* Arterial co2 o2 */

 double i_C_a_co2 = (1-s1)*i_C_e_co2 + s1*i_C_V_co2;
 double i_C_a_o2 = (1-s1)*i_C_e_o2 + s1*i_C_V_o2;

/* P_a_co2/o2 from Spensor equation */
 double D2 = K2*pow((i_C_a_co2/(Z*C2Spencer - i_C_a_co2)),a2);
 double D1 = K1*pow((i_C_a_o2/(Z*C1Spencer - i_C_a_o2)),a1);
 double S2 = -(D2 + alpha2*D2*D1)/(beta1+alpha1*beta2*D1);
 double S1 = -(D1 + alpha1*D1*D2)/(beta2+alpha2*beta1*D2);
 double r1 = -(1+beta1*D2-beta2*D1-alpha1*alpha2*D1*D2)/(2*(beta2+alpha2*beta1*D2));
 double r2 = -(1+beta2*D1-beta1*D2-alpha2*alpha1*D2*D1)/(2*(beta1+alpha1*beta2*D1));
 double i_P_a_co2 = r2+pow((pow(r2,2.00)-S2),.5);
 double i_P_a_o2 = r1+pow((pow(r1,2.00)-S1),.5);




 johncevtor[0]=i_P_B_co2;
 johncevtor[1]=i_P_Vb_co2;
 johncevtor[2]=i_P_B_o2;
 johncevtor[3]=i_P_Vb_o2;
 johncevtor[4]=i_C_Vb_co2;
 johncevtor[5]=i_C_Vb_o2;
 johncevtor[6]=i_P_T_co2;
 johncevtor[7]=i_P_Vt_co2;
 johncevtor[8]=i_P_T_o2;
 johncevtor[9]=i_P_Vt_o2;
 johncevtor[10]=i_C_Vt_co2;
 johncevtor[11]=i_C_Vt_o2;
 johncevtor[12]=i_C_e_co2;
 johncevtor[13]=i_C_e_o2;
 johncevtor[14]=i_Qb;
 johncevtor[15]=i_Qt;
 johncevtor[16]=i_Q;
 johncevtor[17]=i_C_V_co2;
 johncevtor[18]=i_C_V_o2;
 johncevtor[19]=i_C_a_co2;
 johncevtor[20]=i_C_a_o2;
 johncevtor[21]=i_P_a_co2;
 johncevtor[22]=i_P_a_o2;





 return johncevtor;
}

void derivs (int *neq, double *t, double *y, double *ydot, double *yout, int *ip){
if (ip[0] < 0 ) error("nout not enough!");
time_t s = time(NULL);

/* if((int) s - (int) starttime > timeout) error("timeoutsss!");
*/

 double P_B_co2, P_Vb_co2,
		P_B_o2, P_Vb_o2, C_Vb_co2, C_Vb_o2, P_T_co2,
		P_Vt_co2, P_T_o2, P_Vt_o2, C_Vt_co2, C_Vt_o2,
		C_e_co2, C_e_o2, Qb, Qt, Q, C_V_co2, C_V_o2, C_a_co2,
		C_a_o2, P_a_co2, P_a_o2;

 double* intermediate_list= calc_intermediate(y);

// printf("%f\n", intermediate_list[21]);

 P_B_co2=intermediate_list[0];  P_Vb_co2=intermediate_list[1];
 P_B_o2=intermediate_list[2];  P_Vb_o2=intermediate_list[3];
 C_Vb_co2=intermediate_list[4];  C_Vb_o2=intermediate_list[5];
 P_T_co2=intermediate_list[6];  P_Vt_co2=intermediate_list[7];
 P_T_o2=intermediate_list[8];  P_Vt_o2=intermediate_list[19];
 C_Vt_co2=intermediate_list[10];  C_Vt_o2=intermediate_list[11];
 C_e_co2=intermediate_list[12];  C_e_o2=intermediate_list[13];
 Qb=intermediate_list[14];  Qt=intermediate_list[15];  Q=intermediate_list[16];
 C_V_co2=intermediate_list[17];  C_V_o2=intermediate_list[18];
 C_a_co2=intermediate_list[19];  C_a_o2=intermediate_list[20];
 P_a_co2=intermediate_list[21];  P_a_o2=intermediate_list[22];


/*} */
double P_e_co2=y[11]; double P_e_o2=y[12];


double ReactionFlux19=1.00/V_B*(Qb*(C_a_co2 - C_Vb_co2)+M_B_co2);

/* O2 brain */
/* if(P_B_o2>6){
double M_B_o2 = M_B_o2_0;
}
else {
	M_B_o2 = 1/6*M_B_o2_0*P_B_o2;
} */
double M_B_o2 ; /*= 1/6*M_B_o2*P_B_o2;
if(P_B_o2>6){
	M_B_o2 = M_B_o2_0;
} */

if(P_B_o2>6.00){
	M_B_o2=M_B_o2_0;
}else{
	M_B_o2=1.00/6.00*M_B_o2_0*P_B_o2 ;
}


double ReactionFlux20=1.00/V_B*(Qb*(C_a_o2 - C_Vb_o2)+M_B_o2);
double ReactionFlux21=1.00/V_T*(Qt*(C_a_co2 - C_Vt_co2)+M_T_co2);
/*O2 in tissue */

 /* if(P_T_o2>6){
double M_T_o2 = M_T_o2_0;
}
else{
double M_T_o2 = 1/6*M_T_o2_0*P_T_o2;
} */

double M_T_o2 = 1.00/6*M_T_o2_0*P_T_o2;
if(P_T_o2 > 6.00){
	M_T_o2 = M_T_o2_0;
}

double ReactionFlux22=1.00/V_T*(Qt*(C_a_o2 - C_Vt_o2)+M_T_o2);

/* Vent Function Delay */
double Plag_P_a_co2;
double Plag_P_a_o2;
double Plag_C_B_co2;
double Clag_P_a_co2;
double Clag_P_a_o2;
double Clag_P_B_co2;

if(1>0){
double peripherialdelay = K_Dp/Q;
double centraldelay = K_Dc/Q;
double history = *t - peripherialdelay;
//printf("%f ",*t);

	if(history<0){
		  Plag_P_a_co2 = P_a_co2;
		  Plag_P_a_o2 = P_a_o2;
		  Plag_C_B_co2=y[13];
	}else{
//printf("-----------");
		int Nout1 = 1;
		int nr1[1]= {13};
		double ytau1[1] = {0};
		lagvalue(&history, nr1,Nout1,ytau1);
		double Plag_C_B_co2 = ytau1[0];
		 y[13] = Plag_C_B_co2;
		printf("  >>=");
		printf("%f ",Q);

//		printf("%f ",history);
		printf("<<  ");

		int Nout2 = 1;
		int nr2[1] = {14};
		double ytau2[1] = {0};
		lagvalue(&history, nr2, Nout2, ytau2);
		y[14] =ytau2[0];

		int Nout3 = 1;
		int nr3[1] = {15};
		double ytau3[1] = {0};
		lagvalue(&history, nr3, Nout3, ytau3);
		y[15]=ytau3[0];

		int Nout4 = 1;
		int nr4[1] = {16};
		double ytau4[1] = {0};
		lagvalue(&history, nr4, Nout4, ytau4);
		y[16]=ytau4[0];

		int Nout5 = 1;
		int nr5[1] = {11};
		double ytau5[1] = {0};
		lagvalue(&history, nr5, Nout5, ytau5);
		y[11]=ytau5[0];

		int Nout6 = 1;
		int nr6[1] = {12};
		double ytau6[1] = {0};
		lagvalue(&history, nr6, Nout6, ytau6);
		y[12]=ytau6[0];

		int Nout7 = 1;
		int nr7[1] = {19};
		double ytau7[1] = {0};
		lagvalue(&history, nr7, Nout7, ytau7);
		y[19]=ytau7[0];

		int Nout8 = 1;
		int nr8[1] = {18};
		double ytau8[1] = {0};
		lagvalue(&history, nr8, Nout8, ytau8);
		y[18]=ytau8[0];

		double* Plag_intermediate = calc_intermediate(y); /*, &johncevtor[23]) */

						Plag_P_a_co2 =  Plag_intermediate[21];
						Plag_P_a_o2 =  Plag_intermediate[22];

    }

	 history = *t - centraldelay;
	if(history<=0){
		Clag_P_B_co2 = P_B_co2;
	}
	else{

				int Nout1 = 1;
				int nr1[1]= {13};
				/* printf("%d", nr1[1]);
*/
				double ytau1[1] = {0};
				lagvalue(&history, nr1,Nout1,ytau1);
//				printf("Lagvalues");
//				printf("%f", ytau1[0]);
				double Plag_C_B_co2 = ytau1[0];
				y[13] = Plag_C_B_co2;

				int Nout2 = 1;
				int nr2[1] = {14};
				double ytau2[1] = {0};
				lagvalue(&history, nr2, Nout2, ytau2);
				y[14]=ytau2[0];

				int Nout3 = 1;
				int nr3[1] = {15};
				double ytau3[1] = {0};
				lagvalue(&history, nr3, Nout3, ytau3);
				y[15]=ytau3[0];

				int Nout4 = 1;
				int nr4[1] = {16};
				double ytau4[1] = {0};
				lagvalue(&history, nr4, Nout4, ytau4);
				y[16]=ytau4[0];

				int Nout5 = 1;
				int nr5[1] = {11};
				double ytau5[1] = {0};
				lagvalue(&history, nr5, Nout5, ytau5);
				y[11]=ytau5[0];

				int Nout6 = 1;
				int nr6[1] = {12};
				double ytau6[1] = {0};
				lagvalue(&history, nr6, Nout6, ytau6);
				y[12]=ytau6[0];

				int Nout7 = 1;
				int nr7[1] = {19};
				double ytau7[1] = {0};
				lagvalue(&history, nr7, Nout7, ytau7);
				y[19]=ytau7[0];

				int Nout8 = 1;
				int nr8[1] = {18};
				double ytau8[1] = {0};
				lagvalue(&history, nr8, Nout8, ytau8);
				y[18]=ytau8[0];
				double*Clag_intermediate = calc_intermediate(y); /*, &johncevtor[23]); */

				 Clag_P_a_co2 =  Clag_intermediate[21];
				Clag_P_a_o2 =  Clag_intermediate[22];
 				 Clag_P_B_co2 = Clag_intermediate[0];

	}
}

/* Blood flow control */

double psai_co2 = (Aco2+Bco2/(1+Cco2*pow(P_a_co2,Dco2)))/(Aco2+Bco2/(1+Cco2*pow(P_a_co2_0,Dco2)))-1;
double ReactionFlux24=1.00/tau_co2*(psai_co2 - y[18]);
//printf("%f  ", ReactionFlux24);
//printf("%f  ", pow(P_a_co2,Dco2));

double psai_o2 = c1o2*(exp(-P_a_o2/c2o2)- exp(-P_a_o2_0/c2o2));

double ReactionFlux25=1.00/tau_o2*(psai_o2 - y[19]);

/* Ventilation Control */

/* double f_pc=K_fpc*log(P_a_co2/Bp)*(f_pc_max+f_pc_min*exp((P_a_o2 - P_a_o2_c)/K_pc))/(1+exp((P_a_o2-P_a_o2_c)/K_pc));

*/
double f_pc=K_fpc*log(P_a_co2/Bp)*(f_pc_max+f_pc_min*exp((P_a_o2 - P_a_o2_c)/K_pc))/(1+exp((P_a_o2-P_a_o2_c)/K_pc));

double Plag_f_pc=K_fpc*log(Plag_P_a_co2/Bp)*(f_pc_max+f_pc_min*exp((Plag_P_a_o2 - P_a_o2_c)/K_pc))/(1+exp((Plag_P_a_o2-P_a_o2_c)/K_pc));
//printf("%f  ", Plag_P_a_co2);
//printf("%f  ", Bp);

double AV1=1-pow(y[9],P1);

/*Plag drive */
double ReactionFlux26=1.00/tau_Dp*(-y[20] + AV1*G_Dp*(Plag_f_pc - f_pc_0));

/*Clag drive */
double AV2 = 1 - pow(y[9],P2);

double ReactionFlux27 = 1.00/tau_Dc*(-y[21] + AV2*G_Dc*(Clag_P_B_co2 - P_B_co2_0));

double Hstat;
if(P_B_o2 <= theta_Hmin){
	Hstat =1 + Gh*((theta_Hmin - P_B_o2_0)/P_B_o2_0);
}

if((P_B_o2 <= theta_Hmax) && (P_B_o2 > theta_Hmin)){
	 Hstat = 1 + Gh*((P_B_o2 - P_B_o2_0)/P_B_o2_0);
}
if(P_B_o2 > theta_Hmax){
	 Hstat = 1 + Gh*((theta_Hmax - P_B_o2_0)/P_B_o2_0);
}

double ReactionFlux28 = 1.00/tau_h*(Hstat - y[22]);

/*Opioid Wakefulness */

double Kf = K0*pow(y[9],P3);

double totalVentilation = W - Kf + y[22]*y[20] +y[21];
double Venti = totalVentilation*0.66/60.00;
if(Venti< 0)
	Venti=0;

if(y[0]>-1e-9 && y[0]<1e-9) {y[0]=0;}
if(y[1]>-1e-9 && y[1]<1e-9) {y[1]=0;}
if(y[2]>-1e-9 && y[2]<1e-9) {y[2]=0;}
if(y[3]>-1e-9 && y[3]<1e-9) {y[3]=0;}
if(y[4]>-1e-9 && y[4]<1e-9) {y[4]=0;}
if(y[5]>-1e-9 && y[5]<1e-9) {y[5]=0;}
if(y[6]>-1e-9 && y[6]<1e-9) {y[6]=0;}
if(y[7]>-1e-9 && y[7]<1e-9) {y[7]=0;}
if(y[8]>-1e-9 && y[8]<1e-9) {y[8]=0;}
if(y[9]>-1e-9 && y[9]<1e-9) {y[9]=0;}
if(y[10]>-1e-9 && y[10]<1e-9) {y[10]=0;}
if(y[11]>-1e-9 && y[11]<1e-9) {y[11]=0;}
if(y[12]>-1e-9 && y[12]<1e-9) {y[12]=0;}
if(y[13]>-1e-9 && y[13]<1e-9) {y[13]=0;}
if(y[14]>-1e-9 && y[14]<1e-9) {y[14]=0;}
if(y[15]>-1e-9 && y[15]<1e-9) {y[15]=0;}
if(y[16]>-1e-9 && y[16]<1e-9) {y[16]=0;}
if(y[17]>-1e-9 && y[17]<1e-9) {y[17]=0;}
if(y[18]>-1e-9 && y[18]<1e-9) {y[18]=0;}
if(y[19]>-1e-9 && y[19]<1e-9) {y[19]=0;}
if(y[20]>-1e-9 && y[20]<1e-9) {y[20]=0;}
if(y[21]>-1e-9 && y[21]<1e-9) {y[21]=0;}
if(y[22]>-1e-9 && y[22]<1e-9) {y[22]=0;}

ydot[0] = -(ktr*F*y[0])-((1-F)*ktr*y[0]);
ydot[1] = (ktr*F*y[0])-(ktr*y[1]);
ydot[2] = -(1*kin*y[2])+(ktr*y[1]);
ydot[3] = (1.00/V1)*((1*kin*y[2])-(kout2*y[3]));
ydot[4] = (k2*y[3]*1e6/(327.27))-(k2*y[4]);
ydot[5] = -(kout*y[5])-(k12*y[5])+(k21*y[6])+(k31*y[7])-(k13*y[5]);
ydot[6] = (k12*y[5])-(k21*y[6]);
ydot[7] = (k13*y[5])-(k31*y[7]);
ydot[8] = (k1*1e6*y[5]*1000.00/10.5/Mmass)-(k1*y[8]);
ydot[9] = (A1*(1-y[9]-y[10])*(pow(fL*y[8],n)))-(B1*y[9]);
ydot[10] = (A2*(1-y[9]-y[10])*(pow(fN*y[4],n2)))-(B2*y[10]);
ydot[11] = (1.00/V_A*(Venti*(P_I_co2 - y[11]) + lumbda*Q*(1-s1)*(C_V_co2 - C_e_co2)));
ydot[12] = (1.00/V_A*(Venti*(P_I_o2 - y[12]) + lumbda*Q*(1-s1)*(C_V_o2 - C_e_o2)));
ydot[13] = ReactionFlux19; /* dC_B_co2 */
ydot[14] = ReactionFlux20; /* dC_B_o2 */
ydot[15] = ReactionFlux21; /* dC_T_co2 */
ydot[16] = ReactionFlux22; /* dC_T_o2 */
ydot[17] = 0;
ydot[18] =ReactionFlux24; /* dyco2 */
ydot[19] =ReactionFlux25; /* dyo2 */
ydot[20] =ReactionFlux26; /* Dp */
ydot[21] =ReactionFlux27; /* Dc */
ydot[22] =ReactionFlux28; /* dalphaH */
yout[0]=C_a_co2;
yout[1]=P_a_co2;
yout[2]=C_a_o2;
yout[3]=C_V_co2;
yout[4]=C_e_co2;
yout[5]=C_Vb_co2;
yout[6]=C_Vt_co2;
yout[7]=ydot[0];
yout[8]=Venti;

}
