#require(deSolve)
source("optimizer.R")
outdir="plot_results_00_iman_tracethecode/"
#system("R CMD SHLIB /scratch/mohammadreza.samieegohar/Transfers/John_paper/john1/newmodel_realworldbreathing05022021/models/delaymymod.c");

molar_mass<-336.4
encode_pars<-function(pars) pmax1*log10(pars/low_bounds)/log10(high_bounds/low_bounds)
decode_pars<-function(ind) low_bounds*(high_bounds/low_bounds)^(ind/pmax1)

#dyn.load("models/delaymymod.so")
source("../models/delaypars.R")
#--- 2.5 Minute delay
initialdelay<- 2.5*60
V0<-12


Bmax<-20; P1<-9; P2<-2.365;                                    #new PD parameters for chronic
Bmax<-29.65; P1<-5.2; P2<-1.629;                                    #new PD parameters for chronic
compare2fentanyl<-0
if(1> compare2fentanyl){
	drug<-"fentanyl"
# the optimal patient for fentanyl
	parms<-c(F =.6349, kin=.0001775,kout=.002,ktr=.004741, kout2=89.26 ,k1=.00068, k2=.001774,k12=.0032, 
			k13=.0036, k21=.0023, k31=.00023,
			#A1=4.523E-5,B1=.004004,n=.8272,
			A1=3.08E-5, B1=0.004331, n=0.8439,
			A2=0.000167,B2=0.03959,n2=.858,V1=3224)
	Mmass<-  336.4
}else{
	drug<-"carfentanil"
	### the optimal patient 
	parms<-c(F =.6349, kin=.0001775,kout=.002,ktr=.004741, kout2=89.26 ,k1=.00068, k2=.001774,k12=.0032, 
			k13=.0036, k21=.0023, k31=.00023,
			A1=9.95E-6,B1=2.47E-4,n=1.025,A2=0.000167,B2=0.03959,n2=.858,V1=3224)
	Mmass<-  394.5
}

namesyout=c("P_a_co2","C_a_co2","P_a_o2","C_a_o2","C_V_o2","C_V_co2","C_B_o2","C_B_co2","P_A_co2","P_A_o2","C_e_co2","C_e_o2","C_Vb_o2","C_Vb_co2","P_Vb_o2","P_Vb_co2","C_Vt_o2","C_Vt_co2","P_Vt_o2","P_Vt_co2","P_B_co2","Qt","Venti","Plag_f_pc","Plag_P_a_co2","Plag_P_a_co2","Plag_P_a_o2","Qt","psai_co2","Qb","P_B_o2","Clag_P_B_co2","W-kf")

#source("models/delaymodelfun.R")
dyn.load("../models/delaymymod.so")

#source("models/delaymodelfun.R")
set.seed(100)
#optpar=read.table(paste0("results/fentanyl_parsAll.txt"))
#pars=optpar$V2
#names(pars)=optpar$V1
#--- 2.5 Minute delay
initialdelay<- 2.5*60
V0<-12


Bmax<-20; P1<-9; P2<-2.365;                                    #new PD parameters for chronic
Bmax<-29.65; P1<-5.2; P2<-1.629;                                    #new PD parameters for chronic
compare2fentanyl<-0
if(1> compare2fentanyl){
drug<-"fentanyl"
# the optimal patient for fentanyl
parms<-c(F =.6349, kin=.0001775,kout=.002,ktr=.004741, kout2=89.26 ,k1=.00068, k2=.001774,k12=.0032, 
		k13=.0036, k21=.0023, k31=.00023,
		#A1=4.523E-5,B1=.004004,n=.8272,
	    A1=3.08E-5, B1=0.004331, n=0.8439,
		A2=0.000167,B2=0.03959,n2=.858,V1=3224,Mmass=336.4)

}else{
drug<-"carfentanil"
### the optimal patient 
parms<-c(F =.6349, kin=.0001775,kout=.002,ktr=.004741, kout2=89.26 ,k1=.00068, k2=.001774,k12=.0032, 
		k13=.0036, k21=.0023, k31=.00023,
		A1=9.95E-6,B1=2.47E-4,n=1.025,A2=0.000167,B2=0.03959,n2=.858,V1=3224,Mmass=394.5)

}

parmsidx<-match(names(pars), names(parms),nomatch=0)
pars[parmsidx!=0]<- parms[parmsidx]
allpatients<-c(pars,initialdelay=initialdelay)

source("Events.R"); source("crossing.R");
#source("models/delaystates.R");dyn.load("models/delaymymod.so")

allpatients<-as.data.frame(t(allpatients))
uniqdose<-c(0.5, 0.5, 0.5)                       #dose vector
colvec<-c("red","green","gold","cyan","purple")


#breath 10 minutes to reach steady state
this.par<-allpatients[1,]
truepar<-this.par[!names(this.par)=="initialdelay" & !names(this.par)=="Dose"] 
truepar["timeout"]<-3000
#fulltimes<-seq(0,11000,50)
source("models/delaystates.R")
opioid_doseidx<-1; patientidx<-1; threshold<-0.4*states["Venti"]; delay<-150
source("fundedewithEvent.R")
source("fundede.R")

source("VP3.R")
source("VP4.R")
source("VP2.R")
source("VP1.R")
#source("VP3.R")

#source("VP4.R")

#objfun<-function(ind){
	source("../models/delaystates.R")
#	print(ind)
opioid_doseidx<-1; patientidx<-1; threshold<-0.4*states["Venti"]; delay<-150
#initpar0=read.table("models/initial_param_bounds.txt",sep="=",header=T)
#initpar=as.numeric(initpar0[,"Initial"])
#names(initpar)=initpar0[,"Parameter"]

usingCMAESgeneration=F
if(!usingCMAESgeneration){
	optpar=read.table(paste0("../results_00_iman_tracethecode_rev01/fentanyl_pars.txt"))
	#optpar=read.table("../results_Iman/intermittent_fentanyl_pars.txt")
}else{
	CMAESgeneration<-read.table("../results_00_iman_tracethecode_rev01/CMAESgeneration",header=F)
#	optpar=data.frame(V1=c("k1","P1","P2","P3","PP1","PP1","PP3"),V2=t(CMAESgeneration[dim(CMAESgeneration)[1],]))
	optpar=data.frame(V1=c("k1","P1","P2","P3","PP1","PP3","Wmax"),V2=t(CMAESgeneration[dim(CMAESgeneration)[1],]))
	
	colnames(optpar)<-c("V1","V2")
	
	initpar0=read.table("../models/initial_param_bounds.txt",sep="=",header=T)
	initpar=as.numeric(initpar0[,"Initial"])
	names(initpar)=initpar0[,"Parameter"]
#	initpar["P1"]<-3.734159598
#	initpar["P2"]<-0.1
#	initpar["P3"]<-0.9
	lower=initpar
	uper=initpar
	
	lower[1:6]=initpar[1:6]*.1
	uper[1:6]=initpar[1:6]*10
	lower["k1"]=1E-6; uper["k1"]=1E1
	lower["P2"]=1E-4; uper["P2"]=1E1
	lower["Wmax"]=6.62; uper["Wmax"]=10
	lower["P3"]=0.1; uper["P3"]=0.9
	
#	lower[1:7]=initpar[1:7]*.1
#	uper[1:7]=initpar[1:7]*10
#	lower["P3"]=0.1; uper["P3"]=0.9
	low_bounds=lower
	high_bounds=uper
	pmax1=10
}

#optpar$V2<-c(78.54711, 78.74548, 78.27519, 74.73197, 78.01557, 79.93753, 57.86931, 60.77295,63.24961, 61.51904, 67.20149, 64.04684, 67.54757, 60.12162, 37.34260)

initpar=optpar$V2
names(initpar)=optpar$V1
ind=initpar
if(usingCMAESgeneration){
	ind_de=decode_pars(ind) #if ind or initpar or optpar from CMAESgeneration, then they are not decoded yet
}else{ind_de=ind}

#truepar["G_Dp"]=2.5; 
#truepar["G_Dc"]=2 
ind_de["P1"]=2.5
ind_de["PP1"]=3.5
ind_de["k1"]=0.003
ind_de["P2"]=0.06319
ind_de["P3"]=0.9
ind_de["PP3"]=1.26
ind_de["Wmax"]=6.62
truepar["Wmax"]=6.62

EVP1=fVP1(ind_de);  
source("EmaxVP1.R"); EVP1=EmaxfVP1(ind_de)
EVP2=fVP2(ind_de)
source("EmaxVP2.R"); EVP2=EmaxfVP2(ind_de)
EVP3=fVP3(ind_de)
EVP4=fVP4(ind_de)
source("VP5.R")
fVP5(ind_de)
source("VP_B.R")
fVPB(ind_de)
source("VP_A_F.R")
fVP_A_F(ind_de)
source("VP_Suf.R")
fVP_S(ind_de)
print("ploting is done----------------------------------------!")
