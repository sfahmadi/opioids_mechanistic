fVP_A_F <- function(ind){
	
	print("VP1")
ind_Selected=ind[c("k1","P1","P2","P3")]

#nptarget=names(truepar)%in%names(ind_Selected)
#truepar[nptarget]=ind_Selected
	nptarget=match(names(truepar), names(ind_Selected), nomatch=0)
	truepar[nptarget!=0]<- ind_Selected[nptarget]
truepar=unlist(truepar)
#out <- ode(y=states, times=fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=11, rtol=1e-3, atol=1e-6, method="lsoda")
#	print(truepar)
	
	patien_case<-"Fentanyl"
	
	#expdata<-read.csv("paper_digitilized/Alfentanil_Fentanyl_Conc_effect_relationship.csv")
	expdata<-read.csv("paper_digitilized/Alfentanil_Fentanyl__Venti_A.csv")
	expdata_F<-expdata[expdata$Drug=="Fentanyl",]
	expdata_F$Venti<-expdata_F$Venti/9.9
	expdata_F$VentiA<-expdata_F$VentiA/4.8
colnames(expdata_F)[1] <-"PlasmaC"
print(names(expdata_F))
	it_1=30 #runing for Steady state condition , in paper was 120 but Zhihua said 20 min is enough
	eventtimes=c(it_1*60,(it_1+10)*60,(it_1+20)*60,(it_1+30)*60,(it_1+40)*60,(it_1+50)*60,(it_1+60)*60,
			(it_1+70)*60,(it_1+80)*60,(it_1+90)*60,(it_1+100)*60) #min 10-100 minutes following steady state condition
#		print((eventtimes))
	
		eventdose=c(0,.1,.16,.25,.4,.63,1,1.6,2.5,4,6.3)*truepar["VP"]/1e3 #ng/ml > mg 
		#eventdata<-data.frame(var="FIV",time=eventtimes,value=eventdose,method="add")
		eventdata<-data.frame(var="PlasmaF",time=eventtimes,value=eventdose,method="replace")

source("models/delaystates.R")
truepar["starttime"]<-unclass(as.POSIXct(strptime(date(),"%c")))[1]


#-------------------------------------------
#first 30 min steady state by changing P_A_co2 and P_A_o2
fulltimes=seq(0,30*60,10)
#fulltimes=seq(0,500,1)
#print()
#try({out <- dede(states, fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=33, rtol=1e-14, atol=1e-14, method="adams")});
#colnames(out)[(length(states)+2):(length(states)+length(namesyout)+1)]=namesyout
out=fundede(states=states,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)
#out <- dede(y=states, times=fulltimes, func=modelfun, parms=truepar, rtol=1e-14, atol=1e-14, method="lsoda")
# turn of d(PACO2 and dPAo2) -------------------------
states1=out[nrow(out),names(states)]
print("----------Shutting off PK--------")
truepar["kout"]=0
truepar["k12"]=0
truepar["k21"]=0
truepar["k13"]=0
truepar["k31"]=0
fulltimes=seq(0,150*60,1) #fix it later

out1=fundedewithEvent(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout,eventdata=eventdata)

calc_times<-c(8,18,28,38,48,58,68,78,88,98,108)+it_1; 
ypred<-data.frame(out1)
write.csv(ypred,"figs/Test_Fentanyl_prediction.csv")

test<-sapply(calc_times, function(x) {
			testout<-out1[out1[,"time"]>=(60*x)&out1[,"time"]<=(60*(x+2)),];
			output<-data.frame(t(colMeans(testout))); colnames(output)<-colnames(testout); return(output)
			#data.frame(Venti=mean(testout[,"Venti"]),P_a_o2=mean(testout[,"P_a_o2"]),avgPaCO2=mean(testout[,"P_a_co2"]))
		}, simplify=T)

ypred1=t(test)
print("AAAA")


#ypred2=ypred1[,c("time","PlasmaF","Venti","P_a_co2","P_a_o2")]	
#ypred2<-data.matrix(ypred2)               #unnest list columns
#ypred2<-data.frame(ypred2)
ypred2<-data.frame(time=unlist(ypred1[,"time"]),PlasmaF=unlist(ypred1[,"PlasmaF"]),
		 Venti=unlist(ypred1[,"Venti"]),P_a_co2=unlist(ypred1[,"P_a_co2"]),P_a_o2=unlist(ypred1[,"P_a_o2"]))
ypred2$Venti<-ypred2[,"Venti"]/ypred2[1,"Venti"] #normalization

plotypred=ypred2
write.csv(plotypred,"figs/Test_Fentanyl_pred_Plot.csv")
print("BBBBB")


#plotypred=data.frame(plotypred)

#plotin----------------------------
print("ploting...")

pdf(file="figs/VP_F_pred_2.pdf")
plot(expdata_F$PlasmaC,expdata_F$PaO2mm,col="green",xlab="Plasma Concentration",ylab="Partial Pressure O2",
		ylim=c(55,110),pch=19)
#print("1")
lines(plotypred$PlasmaF*1e3/truepar["VP"],plotypred$P_a_o2,col="blue")
plot(expdata_F$PlasmaC,expdata_F$PaCo2mm,col="green",xlab="Plasma Concentration",ylab="Partial Pressure CO2",
		ylim=c(30,60),pch=19)
#print("2")
lines(plotypred$PlasmaF*1e3/truepar["VP"],plotypred$P_a_co2,col="blue")
plot(expdata_F$PlasmaC,expdata_F$Venti,col="green",xlab="Plasma Concentration",ylab="Ventilation",
		ylim=c(.2,1),pch=19)
lines(plotypred$PlasmaF*1e3/truepar["VP"],plotypred$Venti,col="blue")
plot(expdata_F$PlasmaC,expdata_F$VentiA,col="green",xlab="Plasma Concentration",ylab="Ventilation",
		ylim=c(.4,1),pch=19)
lines(plotypred$PlasmaF*1e3/truepar["VP"],plotypred$Venti,col="blue")
dev.off()
}