fVP3 <- function(ind){

	print("VP3")

ind_Selected=ind[c("k1","P1","P2","P3")]

#nptarget=names(truepar)%in%names(ind_Selected)
#truepar[nptarget]=(ind_Selected)

nptarget=match(names(truepar), names(ind_Selected), nomatch=0)
truepar[nptarget!=0]<- ind_Selected[nptarget]

truepar["kout"]<- 4.313e-3;truepar["k12"]<- 3.171e-3;
truepar["k21"]<- 1.569e-2; truepar["k31"]<- 9.777e-5;
truepar["k13"]<- 1.92e-3; truepar["VP"]<- 7.031;

truepar=unlist(truepar)
source("models/delaystates.R")
truepar["starttime"]<-unclass(as.POSIXct(strptime(date(),"%c")))[1]
fulltimes=seq(0,60*60,10) #donot use large time step

	out=fundede(states=states,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)

stateidx<-match(names(states), colnames(out),nomatch=0)
states[stateidx!=0]<- out[dim(out)[1],stateidx]
#states["consciousnessfactor"]<-0  #this factor should be renewed
	print("VP3- afterSS--------")
	
source("patientWrapper.R")
pp<-patientWrapper(doseidx=opioid_doseidx,patientidx=patientidx,delay=delay,threshold=threshold,truepar=truepar,states=states)
print("VP3")

#print(head(pp[[1]][[1]][,c("Venti","time")]))
ypred=pp[[1]][[1]][,c("PlasmaF","P_a_co2","P_a_o2","Venti","time")]

#eror at t==0
ypred_t0=ypred[ypred[,"time"]==0,"Venti"]
ypred_t0o2=pp[[1]][[1]][,c("P_a_o2","time")]
ypred_t0co2=pp[[1]][[1]][,c("P_a_co2","time")]


ypred1=ypred[ypred[,"time"]<=3600,]
ypred1[,"Venti"]=ypred1[,"Venti"]/(ypred1[1,"Venti"])

min_vent=min(ypred1[,"Venti"])





#---------Plasma--------------
Plasma_exp=read.csv("expdata/Plasma.csv",header=F)
colnames(Plasma_exp)=c("time","expplasma")
Plasma_exp["time"]=round(Plasma_exp[,"time"]*60,-1)
print(max(fulltimes))
Plasma_exp=Plasma_exp[Plasma_exp[,"time"]<=max(fulltimes),]
print(Plasma_exp)

idxPeaktimePlasma=ypred1[,"time"]%in%Plasma_exp[,"time"]
#print(ypred1[idxPeaktimePlasma,"time"])
#print(ypred1[,"PlasmaF"])
print(truepar["VP"])
ypred1[,"PlasmaF"]=ypred1[,"PlasmaF"]/truepar["VP"]*1e3
ypredPPlasma=ypred1[idxPeaktimePlasma,"PlasmaF"] # 10.5L Plasma Volume 1e3 ug/mg Conversion from mg to ug/L
EPlasma=sum(((ypredPPlasma-Plasma_exp[,"expplasma"])/max(Plasma_exp[,"expplasma"]))^2)
print(EPlasma)
#print("ffffff")
#print(ypredPPlasma)
#print(Plasma_exp[,"expplasma"])

if (length(ypredPPlasma)!=length(Plasma_exp[,"expplasma"])) {print("Vp3--------"); stoop }


#---------------------o2 co2
o2_exp=read.csv("expdata/Pao2.csv",header=F)
co2_exp=read.csv("expdata/PaCo2.csv",header=F)
colnames(o2_exp)=c("time","expo2")
colnames(co2_exp)=c("time","expco2")
o2_exp["time"]=round(o2_exp["time"]*60,-1)
co2_exp["time"]=round(co2_exp["time"]*60,-1)
o2_exp=o2_exp[o2_exp["time"]<=max(fulltimes),]
co2_exp=co2_exp[co2_exp["time"]<=max(fulltimes),]

o2_exp[,"expo2"]=o2_exp[,"expo2"]
co2_exp[,"expco2"]=co2_exp[,"expco2"]

idxPeaktimeo2=ypred1[,"time"]%in%o2_exp[,"time"]
idxPeaktimeco2=ypred1[,"time"]%in%co2_exp[,"time"]

ypredPo2=ypred1[,c("time","P_a_o2")]
ypredPco2=ypred1[,c("time","P_a_co2")]

ypredPo2[,"P_a_o2"]=ypred1[,"P_a_o2"]/ypred1[1,"P_a_o2"]
ypredPco2[,"P_a_co2"]=ypred1[,"P_a_co2"]/ypred1[1,"P_a_co2"]

#ypredPo2=ypred1[idxPeaktimeo2,"P_a_o2"]
#ypredPco2=ypred1[idxPeaktimeco2,"P_a_co2"]

#---------------------ventilation 
v_exp=read.csv("expdata/expvent.csv",header=F)
colnames(v_exp)=c("time","exp_vent")
v_exp["time"]=round(v_exp["time"]*60,-1)
v_exp=v_exp[v_exp["time"]<=2000,]
#v_exp=v_exp[,"exp_vent"]/60
idxPeaktime=ypred1[,"time"]%in%v_exp[,"time"]

ypred2=ypred1[idxPeaktime,"Venti"]	
ypredt=ypred1[idxPeaktime,"time"]	

#ErrorV=0
E2=(ypred2-v_exp[,"exp_vent"])[2]
E3=(ypred2-v_exp[,"exp_vent"])[3]
E4=(ypred2-v_exp[,"exp_vent"])[4]
E5=(ypred2-v_exp[,"exp_vent"])[5]
E6=(ypred2-v_exp[,"exp_vent"])[6]
print(E2)
print(E3)
print(E4)
print(E5)
print(E6)
#print("-------------")


Eo2=sum((ypredPo2[idxPeaktimeo2,"P_a_o2"]-o2_exp[,"expo2"])^2)
Eco2=sum((ypredPco2[idxPeaktimeco2,"P_a_co2"]-co2_exp[,"expco2"])^2)

ypredW=pp[[1]][[1]][,c("W-kf","time")]
W10=ypredW[,"W-kf"][ypredW[,"time"]==10*60]
#print(ypredW[,"W"])
ypredDc=pp[[1]][[1]][,c("Dc","time")]
Dc=ypredDc[,"Dc"][ypredDc[,"time"]==10*60]

ypredDp=pp[[1]][[1]][,c("Dp","time")]
Dp=ypredDp[,"Dp"][ypredDp[,"time"]==10*60]

Eimp=Dp+Dc-truepar["Td"]

ypredpAco2=pp[[1]][[1]][,c("P_a_co2","time")]
ypredpAco20=ypredpAco2[,"P_a_co2"][ypredpAco2[,"time"]==0]

ypredpAo2=pp[[1]][[1]][,c("P_a_o2","time")]
ypredpAo20=ypredpAo2[,"P_a_o2"][ypredpAo2[,"time"]==0]

#ploting----------------------------
print("ploting...")
print(head(ypredPo2))
jpeg(file="figs/VP3.jpeg",width=6, height=6, units="in", res=400)
par(mfrow=c(2,2))
#ypred=pp[[1]][[1]][,c("PlasmaF","P_a_co2","P_a_o2","Venti","time")]

#print(expdata_Naive_Fr$time)
plot(v_exp[,"time"]/60, v_exp[,"exp_vent"],  col = "green",xlab="time(min)", ylab="Fractional Ventilation",ylim=c(0,1 ),pch=19,xlim=c(0,max(fulltimes/60)))
lines(ypred1[,"time"]/60, ypred1[,"Venti"],  col = "blue")

plot(Plasma_exp[,"time"]/60, Plasma_exp[,"expplasma"],  col = "green",xlab="time(min)", ylab="plasmaF(um/l)",ylim=c(0,max(Plasma_exp[,"expplasma"])),pch=19,xlim=c(0,max(fulltimes/60)))
lines(ypred1[,"time"]/60, ypred1[,"PlasmaF"],  col = "blue")

plot(o2_exp[,"time"]/60, o2_exp[,"expo2"],  col = "green",xlab="time(min)", ylab="Fractional pao2",ylim=c(0,max(1.5*o2_exp[,"expo2"]) ),pch=19,xlim=c(0,max(fulltimes/60)))
lines(ypredPo2[,"time"]/60, ypredPo2[,"P_a_o2"],  col = "blue")

plot(co2_exp[,"time"]/60, co2_exp[,"expco2"],  col = "green",xlab="time(min)", ylab="Fractional paco2",ylim=c(0,max(1.5*co2_exp[,"expco2"] )),pch=19,xlim=c(0,max(fulltimes/60)))
lines(ypredPco2[,"time"]/60, ypredPco2[,"P_a_co2"],  col = "blue")

#lines(ypred2$time, ypred2$Venti ,col = "blue")
dev.off()

#plotting death
source("lethaldose.R")
pp<-patientWrapper(doseidx=opioid_doseidx,patientidx=patientidx,delay=delay,threshold=threshold,truepar=truepar,states=states)
ypred=pp[[1]][[1]][,c("PlasmaF","P_a_co2","P_a_o2","Venti","time")]
pdf("figs/death.pdf")
plot(ypred[,"time"]/60, ypred[,"Venti"]*60/0.66,ylab="Ventilation (L/min)",xlab="Time (minutes)")
dev.off()

}