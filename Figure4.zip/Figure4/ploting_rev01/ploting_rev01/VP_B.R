fVPB <- function(ind){

ind_Selected=ind[c("k1","P1","P2","P3")]

#nptarget=names(truepar)%in%names(ind_Selected)
#truepar[nptarget]=ind_Selected
	nptarget=match(names(truepar), names(ind_Selected), nomatch=0)
	truepar[nptarget!=0]<- ind_Selected[nptarget]
truepar=unlist(truepar)
#out <- ode(y=states, times=fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=11, rtol=1e-3, atol=1e-6, method="lsoda")
#	print(truepar)
	
	#-----------------------------------------------
	patien_case="Remi" #later combine Naive and chronic
	
	
	#----- Remifentanil 
	expdata_Remi<-read.csv(paste0("paper_digitilized/barbenco.csv"))
	
	expdata_Remi_Fr<-expdata_Remi[,c(1:3)]
	names(expdata_Remi_Fr)<-c("time","MR","HR")
	
	
	expdata_Remi_Fr$MR=expdata_Remi_Fr$MR/12.9
	expdata_Remi_Fr$HR=expdata_Remi_Fr$HR/12.9
	
	expdata_Remi_Fr$time=expdata_Remi_Fr$time*60
	

	it_1=60 #runing for Steady state condition , in paper was 120 but Zhihua said 20 min is enough


source("models/delaystates.R")
truepar["starttime"]<-unclass(as.POSIXct(strptime(date(),"%c")))[1]


#-------------------------------------------
#first 30 min steady state by changing P_A_co2 and P_A_o2
fulltimes=seq(0,30*60,1)
truepar["A1"]= 8.078E-6
truepar["B1"]= .002076 
truepar["n"]= .7034 

truepar["kout"]=0.494/60
truepar["k1"]=10/60
truepar["k12"]=0.339/60
truepar["k21"]=.188/60
truepar["k13"]=.013/60
truepar["k31"]=.01/60
truepar["VP"]=4.98

#truepar["P1"]=2
#truepar["P2"]=.001
#truepar["P3"]=.8998

#truepar["G_Dp"]=2.5*.78/1.5; truepar["G_Dc"]=2*.78/1.5;
truepar["G_Dp"]=2.5*0.6; truepar["G_Dc"]=2*0.6;

out=fundede(states=states,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)

states1=out[nrow(out),names(states)]
#print(head(out))
print(tail(out))
#truepar["offO2"]=0
#truepar["offCo2"]=0

#---- Fix P_A_co2 or Inspired O2
truepar["offCo2"]=0
#truepar["offO2"]=0
#states1["P_A_o2"]=200
states1["P_I_o2"]=400
#prepare drug events
eqtime=8 #minutes
fulltimes=seq(0,(eqtime+20)*60,1) #  Allow to equilibriate over first 8 minutes. 
eventdose=c(35)*0.001 #um Naive x 0.001 to convert mg
eventtimes=c(eqtime*60+1)
eventdata<-data.frame(var="PlasmaF",time=eventtimes,value=eventdose,method="add")
#first measure at 46 mm Hg
states1["P_A_co2"]=46
out1=fundedewithEvent(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout,eventdata=eventdata)
out46=out1

#then measure at 56 mm Hg
states1["P_A_co2"]=56
out1=fundedewithEvent(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout,eventdata=eventdata)
out56=out1

#then at 50 mm Hg although in experiments this is computed
states1["P_A_co2"]=50
out1=fundedewithEvent(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout,eventdata=eventdata)
out50=out1

#slope
slope = (out56[,"Venti"] - out46[,"Venti"])*60/0.66/10
bpoint = out56[,"Venti"]*60/0.66 - slope*56
computedVe50 = slope*50+bpoint

pdf("figs/slope.pdf")
plot(out56[,"time"],slope)
plot(out56[,c("time","CAR")])
plot(out56[,c("time","PlasmaF")])
dev.off()

out1<-data.frame(time=out50[,"time"],Venti=computedVe50) #using computed instead of measured Ve50
ypred<-data.frame(out1)

ypred1=ypred[ypred[,"time"]<=(eqtime+20)*60,]
expdata_Remi_Fr[,"time"]=round(expdata_Remi_Fr[,"time"]+eqtime*60)
idxPeaktime=ypred1[,"time"]%in%expdata_Remi_Fr[,"time"]
#print(expdata_Remi_Fr[,"time"])
ypred2=ypred1[,c("time","Venti")]	
#ypred2$Venti<-ypred2$Venti/ypred2$Venti[ypred2$time==eventdata$time[1]] #normalization

plotypred=ypred2


expdata_Remi_Fr=data.frame(expdata_Remi_Fr)
expdata_Remi_Fr$MR <- expdata_Remi_Fr$MR*12.9  #de-normalization
plotypred=data.frame(plotypred)

#plotin----------------------------
print("ploting...")

jpeg(file="figs/VpB50_Off_O2_50.jpeg",width=6, height=6, units="in", res=400)
#print(expdata_Naive_Fr$time)
plot(expdata_Remi_Fr$time/60, expdata_Remi_Fr$MR,  col = "green",xlab="time(min)", ylab="Fractional Ventilation",ylim=c(0,20),pch=19,main=sprintf("%s",patien_case))
lines(ypred2$time/60, ypred2$Venti ,col = "blue")
dev.off()
jpeg(file="figs/VPBCAR.jpeg")
plot(ypred$time/60,ypred$CAR,col="red")
dev.off()


}