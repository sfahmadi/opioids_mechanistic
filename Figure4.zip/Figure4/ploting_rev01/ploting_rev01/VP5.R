fVP5 <- function(ind){
	
	print("VP5")
	ind_Selected=ind[c("k1","P1","P2","P3")]
	
#nptarget=names(truepar)%in%names(ind_Selected)
#truepar[nptarget]=ind_Selected
	nptarget=match(names(truepar), names(ind_Selected), nomatch=0)
	truepar[nptarget!=0]<- ind_Selected[nptarget]
truepar=unlist(truepar)


	
#-----------load Experimental data-----------
	clinicaldata<-data.frame(time=c(0,20,40,60,120,180,240,300),
			                  PaCO2=c(39,44,48,50,53,56,59,63),
							  PaO2=c(412,423,452,402,385,383,332,314))
	
	

	

#decreasing O2 comsuption during sleep? probably will make P_a_o2 less matching clinical data
#truepar["M_B_o2_0"]<- pars["M_B_o2_0"]/1.6; truepar["M_T_o2_0"]<-pars["M_T_o2_0"]/1.6
#-------------------------------------------
#steady state with high O2 in anesthetized patients
	truepar["W"]<-6.6; #actually pateints are put to sleep but ventilator can provide forced drive 
	#truepar["G_Dc"]<-0; truepar["G_Dp"]<-0
	truepar["Bmax"]<-0.66;    #Bmax is the "live space"  
	#truepar["offO2"]=0; states["P_A_o2"]=400; #no matter how high P_A_o2 or P_I_o2 is
	truepar["offO2"]=1; states["P_I_o2"]=480; #P_a_o2 can only increase to ~170 mm Hg
	#truepar["offCo2"]=0; states["P_A_co2"]=40; #and this is due to P_a_co2 not high?
	                                           #P_I_o2 might be adjusted to match the shape (but not values) of the clinical data
#normal steady state
fulltimes=seq(0,30*60,10)
out=fundede(states=states,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)
states1=out[nrow(out),names(states)]

#then apnea
truepar["Bmax"]=0;  #here Bmax is "live space of ventilation"
truepar["W"]<-0;    #anesthetization
truepar["offO2"]<-1;  #even when airway obstructed there should still be air exchange in lung
truepar["offCo2"]<-1
fulltimes=seq(0,300,1)

	out1=fundede(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)
	mergedout<-merge(out1[,c("time","P_a_co2","P_a_o2")],clinicaldata,by="time")
	thiserror<- (mergedout[,"P_a_co2"] - mergedout[,"PaCO2"])/mergedout[,"PaCO2"]
	errorvec<-thiserror^2

	
	
	
pdf("figs/VP5.pdf")
plot(mergedout[,c("time","PaCO2")],col="red")
lines(mergedout[,c("time","P_a_co2")],col="green")
legend("topright",legend=c("clincial","model"),fill=c("red","green"))

plot(mergedout[,"time"],mergedout[,"PaO2"]/mergedout[1,"PaO2"],col="red")
lines(mergedout[,"time"], mergedout[,"P_a_o2"]/mergedout[1,"P_a_o2"],col="green")
legend("topright",legend=c("clincial","model"),fill=c("red","green"))


dev.off()

#pdf("figs/VP6.pdf")
#fulltimes<-seq(0,1200)
#out1=fundede(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)
#time1<-out1[,"time"]; vent1<-out1[,"Venti"]*60/0.66; co2_1=out1[,"P_A_co2"];o2_1=out1[,"P_a_o2"]
#So2_1 <- (((o2_1^3 + 150*o2_1)^-1*23400)+1)^-1*100 #Severinghaus equation
#timeidx1<-which(So2_1<=0.98)[1]
#timeidx2<-which(So2_1<=0.9)[1]
#plot(time1[timeidx1:timeidx2], So2_1[timeidx1:timeidx2], xlab="time (seconds)", ylab="SaO2")
#dev.off()
}