fVP2 <- function(ind){
#	source("fundede.R")
	
	print("VP2")
#	ind_Selected=ind[c("K1","P1","P2","P3","K0")]
	ind_Selected=ind[c("k1","PP1","P2","PP3")] #VP2
	names(ind_Selected)=c("k1","P1","P2","P3") #just adjust name
	
#	nptarget=names(truepar)%in%names(ind_Selected)
#	truepar[nptarget]=ind_Selected
	nptarget=match(names(truepar), names(ind_Selected), nomatch=0)
	truepar[nptarget!=0]<- ind_Selected[nptarget]
	truepar=unlist(truepar)
#out <- ode(y=states, times=fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=11, rtol=1e-3, atol=1e-6, method="lsoda")
	
	#-----------------------------------------------
	patien_case="Chronic" #later combine Naive and chronic
	
#-----------load Experimental data-----------
	expdata_Naive<-read.csv(paste0("paper_digitilized/A_Naive.csv"))
	expdata_Naive_Fr=expdata_Naive
	expdata_Naive_Fr$LR=expdata_Naive$LR/mean(expdata_Naive$MR[expdata_Naive$time<110 & expdata_Naive$time>100])
	expdata_Naive_Fr$MR=expdata_Naive$MR/mean(expdata_Naive$MR[expdata_Naive$time<110 & expdata_Naive$time>100])
	expdata_Naive_Fr$HR=expdata_Naive$HR/mean(expdata_Naive$MR[expdata_Naive$time<110 & expdata_Naive$time>100])
	expdata_Naive_Fr$time=expdata_Naive$time*60
	
#-------------------
	expdata_Chronic<-read.csv(paste0("paper_digitilized/B_Chronic.csv"))
	expdata_Chronic_Fr=expdata_Chronic
#iman approach
	expdata_Chronic_Fr$LR=expdata_Chronic$LR/mean(expdata_Chronic$MR[expdata_Chronic$time<110 & expdata_Chronic$time>100])
	expdata_Chronic_Fr$MR=expdata_Chronic$MR/mean(expdata_Chronic$MR[expdata_Chronic$time<110 & expdata_Chronic$time>100])
	expdata_Chronic_Fr$HR=expdata_Chronic$HR/mean(expdata_Chronic$MR[expdata_Chronic$time<110 & expdata_Chronic$time>100])	
	expdata_Chronic_Fr$time=expdata_Chronic$time*60
	
#sstime=10*60 #runing 10 min for Stedystate condision 
	#eventtimes=c(120*60,120*60+pars["Infu_t"],180*60,180*60+pars["Infu_t"],240*60,240*60+pars["Infu_t"],300*60,300*60+pars["Infu_t"]) #min Naive
#	it_1=120
	it_1=60 #runing for Steady state condition , in paper was 120 but Zhihua said 20 min is enough
	eventtimes=c(it_1*60,it_1*60+pars["Infu_t"],(it_1+60)*60,(it_1+60)*60+pars["Infu_t"])#,240*60,240*60+pars["Infu_t"],300*60,300*60+pars["Infu_t"]) #min Naive
#		print((eventtimes))
	
	#sss
	if (patien_case=="Naive") {
		#eventdose=c(75,-75,150,-150,250,-250,350,-350)*0.001 #um Naive x 0.001 to convert mg
		eventdose=c(75,-75,150,-150)*0.001#,250,-250,350,-350)*0.001 #um Naive x 0.001 to convert mg
		
	}
	if (patien_case=="Chronic") {
		eventdose=c(250,-250,350,-350)*0.001#,500,-500,700,-700)*0.001 #um NaiveV x 0.001 to convert mg
	}
	#eventdata<-data.frame(var="FIV",time=eventtimes,value=eventdose,method="add")
	eventdata<-data.frame(var="FIV",time=eventtimes,value=eventdose,method="add")
	
	source("models/delaystates.R")
	truepar["starttime"]<-unclass(as.POSIXct(strptime(date(),"%c")))[1]
	
#-------------------------------------------
#first 30 min steady state by changing P_A_co2 and P_A_o2
	fulltimes=seq(0,30*60,10)
#fulltimes=seq(0,500,1)
#print()
#	try({out <- dede(states, fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=33, rtol=1e-9, atol=1e-9, method="lsoda")});
#	colnames(out)[(length(states)+2):(length(states)+length(namesyout)+1)]=namesyout
out=fundede(states=states,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)

#out <- dede(y=states, times=fulltimes, func=modelfun, parms=truepar, rtol=1e-14, atol=1e-14, method="lsoda")
# turn of d(PACO2 and dPAo2) -------------------------
	states1=out[nrow(out),names(states)]
	truepar["offO2"]=0
	truepar["offCo2"]=0
	
	states1["P_A_co2"]=50
	states1["P_A_o2"]=102
#II>	Change P_A_co2 to a fixed value X and P_A_o2 to a fixed value Y, hold for sometime (10 min?) to reach a new steady state. For Y the paper says:
#end-tidal O2 fixed to 13.5 vol.%. Jeff helped me to convert that to 102.6 mm Hg, so normaxia. For X, probably ~ 50 mm Hg, but one needs to be try a few values 
#so that at the new steady state total ventilation (Venti * 60/0.66) is ~ 20 L/min. An example script to do such fixing O2 and increasing CO2 is in / home/lizhi/documents/sigmoidopioids/realworldbreathing05102021_noWselfrecovery/ simulate_2001Fig3.R
	fulltimes=seq(0,241*60,10) #fix it later

	out1=fundedewithEvent(states=states1,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout,eventdata=eventdata)
	

expdata_Chronic_Fr=expdata_Chronic_Fr[expdata_Chronic_Fr[,"time"]<=240*60,]
expdata_Chronic_Fr[,"time"]=expdata_Chronic_Fr[,"time"]-(120-it_1)*60
expdata_Chronic_Fr=expdata_Chronic_Fr[expdata_Chronic_Fr[,"time"]>=0,]
#print(expdata_Chronic_Fr)
#ccc
ypred<-data.frame(out1)
ypred1=ypred[ypred[,"time"]<=60*240,]
expdata_Chronic_Fr[,"time"]=round(expdata_Chronic_Fr[,"time"])
idxPeaktime=ypred1[,"time"]%in%expdata_Chronic_Fr[,"time"]

ypred2=ypred1[,c("time","Venti")]	
ypred2$Venti<-ypred2$Venti/ypred2$Venti[ypred2$time==eventdata$time[1]] #normalization
plotypred=ypred2


expdata_Chronic_Fr=data.frame(expdata_Chronic_Fr)
#colnames(Efr1)=c("time","qmin","qmax")

plotypred=data.frame(plotypred)



#plotin----------------------------
print("ploting...")

jpeg(file="figs/Vp2.jpeg",width=6, height=6, units="in", res=400)
#print(expdata_Chronic_Fr$time)
plot(expdata_Chronic_Fr$time/60, expdata_Chronic_Fr$MR,  col = "green",xlab="time(min)", ylab="Fractional Ventilation",ylim=c(0,1),pch=19,main=sprintf("%s",patien_case))
lines(ypred2$time/60, ypred2$Venti ,col = "blue")
dev.off()
	
	


}