fVP_S <- function(ind){
	print("VP4")
	
#	
ind_Selected=ind[c("k1","P1","P2","P3")]

#nptarget=names(truepar)%in%names(ind_Selected)
#truepar[nptarget]=(ind_Selected)
	nptarget=match(names(truepar), names(ind_Selected), nomatch=0)
	truepar[nptarget!=0]<- ind_Selected[nptarget]
truepar=unlist(truepar)
source("models/delaystates.R")

print("Convert to Sufentanil Parameters")
A1=1.16e-5;B1=.001072;n=1.022;
truepar["A1"]=A1
truepar["B1"]=B1
truepar["n"]=n
print(truepar["A1"])

print("----------Shutting off PK--------")
truepar["kout"]=0
truepar["k12"]=0
truepar["k21"]=0
truepar["k13"]=0
truepar["k31"]=0
truepar["k1"]=10/60                   #just like remefentanil, assume very fast equilibrum
truepar["starttime"]<-unclass(as.POSIXct(strptime(date(),"%c")))[1]
fulltimes=seq(0,3600,10) # donot use a large time step
#print(truepar)
#print(states)
	states["PlasmaF"]=0 #double check it 
	
	
	
	out=fundede(states=states,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)
	

	
	# Vector of states-------------------------------------
	Vstate=out[out[,"time"]==60*60 | out[,"time"]==30*60,]
	# turn of d(PACO2 and dPAo2) -------------------------
	#str(Vstate)
	truepar["offO2"]=0
	truepar["offCo2"]=0
	All_Co2_Res_baseline=c()
	#if (is.na(Vstate[1,"P_A_co2"]) | is.nan(Vstate[1,"P_A_co2"]) | Vstate[1,"P_A_co2"]>10000 | Vstate[1,"P_A_co2"]< -10000) {EVP4=10000} else {
	if (is.na(Vstate[1,"P_A_co2"]) | is.nan(Vstate[1,"P_A_co2"]) | Vstate[1,"P_A_co2"]>10000 | Vstate[1,"P_A_co2"]< -10000) {EVP4=10000} else {	
	for (i in c(1))	{ #took the 15 minute time point to allow for equilibriation. 
		# event for 20mmkg in 4 min ---------------------------------
		#double check it boss
			eventdose1=seq(Vstate[i,"P_A_co2"],(Vstate[i,"P_A_co2"]+20),5/60) 
			
	#	print(eventdose1)
		#str(eventdose1)
	#print(i)
	eventtimes1=seq(0,4*60) 
	fulltimes=eventtimes1
	statesslop_base=Vstate[i,names(states)]
	eventdata_VP4<-data.frame(var="P_A_co2",time=eventtimes1,value=eventdose1,method="replace")
	
	#print(statesslop_base)
	#out_slop_base=fundede(states=statesslop_base,fulltimes=fulltimes,truepar=truepar,namesyout=namesyout)
	
	try({out_slop_base <- dede(statesslop_base, fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=33, rtol=1e-14, atol=1e-14, method="adams",events=list(data=eventdata_VP4))});
	colnames(out_slop_base)[(length(statesslop_base)+2):(length(statesslop_base)+length(namesyout)+1)]=namesyout
	
	##write.csv(out_slop_base,paste0("outputs/out_slop_base.csv"))
	#note that here Venti is total_venti*0.66/60, so the true slope is
    #Co2_Res_base*60/0.66
	Co2_Res_base=(max(out_slop_base[,"Venti"])-min(out_slop_base[,"Venti"]))/(max(out_slop_base[,"P_A_co2"])-min(out_slop_base[,"P_A_co2"]))# divide by control slope 
	All_Co2_Res_baseline=rbind(All_Co2_Res_baseline,c(Vstate[i,"time"],Co2_Res_base))

}
colnames(All_Co2_Res_baseline)=c("time","Co2_Res")
	
	Suf_Plasma<-read.csv("paper_digitilized/Sufentanil_Plasma.csv")
	Vals_30=Suf_Plasma[,2]*truepar["VP"]/1e3
	print(Vals_30)
	a=(Vals_30[2]-Vals_30[1])/300
	b=(Vals_30[3]-Vals_30[2])/300
	c=(Vals_30[4]-Vals_30[3])/300
	d=(Vals_30[5]-Vals_30[4])/900
	e=(Vals_30[6]-Vals_30[5])/900
	f=(Vals_30[7]-Vals_30[6])/4500
	dose_30=c(rep(a,300),rep(b,300),rep(c,300),rep(d,900),rep(e,900),rep(f,4500))
	doses_30ug<-cbind(a,b,c,d,e,f)
	##write.csv(doses_30ug,"outputs/doses_30ug.csv")
	event_times_plasma<-seq(1,120*60,1)
	
	Event_30<-data.frame(var="PlasmaF",time=event_times_plasma,value=dose_30,method="add")
	
	
	
	Vals_50=Suf_Plasma[,4]*truepar["VP"]/1e3
	print(Vals_50)
	a2=(Vals_50[2]-Vals_50[1])/300
	b2=(Vals_50[3]-Vals_50[2])/300
	c2=(Vals_50[4]-Vals_50[3])/300
	d2=(Vals_50[5]-Vals_50[4])/900
	e2=(Vals_50[6]-Vals_50[5])/900
	f2=(Vals_50[7]-Vals_50[6])/4500
	doses_50ug<-cbind(a2,b2,c2,d2,e2,f2)
	##write.csv(doses_50ug,"outputs/doses_50ug.csv")
	dose_50=c(rep(a2,300),rep(b2,300),rep(c2,300),rep(d2,900),rep(e2,900),rep(f2,4500))
	event_times_plasma<-seq(1,120*60,1)
	
	print("TESTTEST")
	print(Vals_30[1])
	Event_50<-data.frame(var="PlasmaF",time=event_times_plasma,value=dose_50,method="add")
#print(All_Co2_Res_baseline)
	All_CO2_doses<-c()
	concvals=c(.03,.05)
for(idose in concvals){
Baseline=mean(c(All_Co2_Res_baseline[,"Co2_Res"]))
print("Baselin_Ventilation_CO2_Slope")
print(Baseline)
	
	states<-statesslop_base   #drug should be added after baseline steady state #double check it 
print(idose)	
	if(idose==.03){
		states["PlasmaF"]=as.numeric(Vals_30[1])
		event_Plasma=Event_30
		dd<-d
		ff<-f
		
	}else{
		states["PlasmaF"]=as.numeric(Vals_50[1])
		event_Plasma=Event_50
		dd<-d2
		ff<-f2
	}
	
	truepar["offO2"]=1
	truepar["offCo2"]=1
	

#	print(states)
	
fulltimes=seq(0,7500,10); eventtimes<- event_Plasma[,"time"]
fulltimes<-sort(c(eventtimes, cleanEventTimes(fulltimes, eventtimes)))

 try({out2 <- dede(states, fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=33, rtol=1e-14, atol=1e-14, method="adams",events=list(data=event_Plasma))});

	
	
	Vstate=out2[out2[,"time"]==15*60 | out2[,"time"]==45*60 | out2[,"time"]==120*60, ]
	#write.csv(Vstate,paste0("outputs/Vstate",idose,".csv"))
	# turn of d(PACO2 and dPAo2) -------------------------
	truepar["offO2"]=0
	truepar["offCo2"]=0
	
	All_Co2_Res<-c()
#	print(Vstate)
	print(nrow(Vstate))
	#print(Vstate[1,"P"])
	#becase of bad parameter maybe "P_A_co2" is nan or na or -inf ... so here we put a if , to avoid next step oterhwise it stop 
#	if (is.na(Vstate[1,"P_A_co2"]) | is.nan(Vstate[1,"P_A_co2"]) | Vstate[1,"P_A_co2"]>10000 | Vstate[1,"P_A_co2"]< -10000) {EVP4=10000} else {
for (i in 1:nrow(Vstate))	{
	# event for 20mmkg in 4 min ---------------------------------
		#double check it boss
#	eventdose1=seq(Vstate[i,"P_A_co2"],(Vstate[i,"P_A_co2"]+20),5/60) #by 241 (from times) injection , (each time x+5/60) 
	
	eventdose1=seq(Vstate[i,"P_A_co2"],(Vstate[i,"P_A_co2"]+20),5/60) 
	eventtimes1=seq(0,4*60) 
	fulltimes=eventtimes1
	
	#eventdose1=seq(0,20,5/60) #by 241 (from times) injection , (each time x+5/60) 
	eventdata_VP4<-data.frame(var="P_A_co2",time=eventtimes1,value=eventdose1,method="replace")
	if(i==1){
		event_Plasma_i<-data.frame(var="PlasmaF",time=eventtimes1,value=dd,method="add")
	}else{
		event_Plasma_i<-data.frame(var="PlasmaF",time=eventtimes1,value=ff,method="add")
	}
	
	
	event_All<-rbind(eventdata_VP4,event_Plasma_i); eventtimes<-event_All[,"time"]
	fulltimes<-sort(c(eventtimes, cleanEventTimes(fulltimes, eventtimes)))
	event_All<-event_All[order(event_All[,"time"]),]
	statesslop2=Vstate[i,names(states)]
#	print(Vstate[i,"time"])
#	statesslop2["PlasmaF"]=0.5 #double check it shouldn't re-inject fentanyl!
	
	try({out_slop2 <- dede(statesslop2, fulltimes, "derivs", parms=truepar, dllname="delaymymod",initfunc="initmod", nout=33, rtol=1e-14, atol=1e-14, method="adams",events=list(data=event_All))});
	colnames(out_slop2)[(length(statesslop2)+2):(length(statesslop2)+length(namesyout)+1)]=namesyout
	##write.csv(out_slop2,paste0("outputs/out_slop2",idose,"VS",i,".csv"))	
Co2_Res=(max(out_slop2[,"Venti"])-min(out_slop2[,"Venti"]))/(max(out_slop2[,"P_A_co2"])-min(out_slop2[,"P_A_co2"])) # divide by control slope 
Co2_Res<-cbind(Co2_Res,idose)

All_Co2_Res=rbind(All_Co2_Res,c(Vstate[i,"time"],Co2_Res))
names(All_Co2_Res)=c("time","Co2_Res","idose")
}
All_CO2_doses=rbind.data.frame(All_CO2_doses,All_Co2_Res)
}
#names(A)
str(All_CO2_doses)
colnames(All_CO2_doses)=c("time","Co2_Res","idose")
#print(names(All_CO2_doses))
##write.csvcsv(All_CO2_doses,"outputs/All_Cases.csv")
print("CO2 Slopes Percent Baseline")
#names(All_CO2_doses)=c("X","time","Co2_Res","idose")
print(All_CO2_doses[,"Co2_Res"]/Baseline*100)

	#colnames(All_Co2_Res)=c("time","Co2_Res")
#print(All_Co2_Res)
#------------slop CO2-------this should be checked by zhihua
	#SlopCO2_exp=read.csv("expdata/CO2_Slope_Response_Rebreathing.csv",header=T)
SlopCO2_exp=read.csv("paper_digitilized/Sufentanil_CO2_Response.csv")
#	print(SlopCO2_exp)
	SlopCO2_exp["time"]=round(SlopCO2_exp["time_30"]*60,-1)
	plotSlopCO2_exp=SlopCO2_exp
#	print("11111")
	#SlopCO2_exp=SlopCO2_exp[SlopCO2_exp[,"time"]<=3600,]
	#idxPeaktimeSlopCO2=ypred1[,"time"]%in%SlopCO2_exp[,"time"]
	idxPeaktimeSlopCO2=SlopCO2_exp[,"time"]%in%All_Co2_Res[,"time"]
#	print("222")
	
	yexpPSlopCO2=SlopCO2_exp[idxPeaktimeSlopCO2,"slope_30"]	
	timepoints=SlopCO2_exp[idxPeaktimeSlopCO2,"time"]	
	
	#print(All_Co2_Res[,"Co2_Res"])
print("Experimental_Percent_Baseline")
	print(yexpPSlopCO2)
	
#	ESlopCO2=sum(((All_Co2_Res[,"Co2_Res"]/Baseline)-yexpPSlopCO2/100)^2)
#if (length(All_Co2_Res[,"Co2_Res"])!= length(yexpPSlopCO2)) {print("VP4 has a error ! "); stop}
##print("000000000000")
#	
#
#	EVP4=ESlopCO2
	}
	
	
	#plotin----------------------------
	print("ploting...")
	jpeg(file="figs/VP_Suff.jpeg",width=6, height=6, units="in", res=400)
#	print(plotSlopCO2_exp)
	print(max(fulltimes))
	str(All_CO2_doses)
	All_Co2_30<-All_CO2_doses[All_CO2_doses$idose==.03,]
	All_Co2_50<-All_CO2_doses[All_CO2_doses$idose==.05,]
	#print(All_Co2_Res[,"Co2_Res"]/Baseline)	
print(str(plotSlopCO2_exp))
print(str(All_Co2_30))
print(str(All_Co2_50))
	plot(plotSlopCO2_exp$time/60, (plotSlopCO2_exp$slope_30+100)/100,  col = "green",xlab="time(min)", ylab="co2 response (frac)",ylim=c(0,1.5),xlim=c(0,max(out2[,'time'])/60),pch=19)
	points(timepoints/60, All_Co2_30[,"Co2_Res"]/Baseline ,col = "blue",pch=19)
	points(timepoints/60, All_Co2_50[,"Co2_Res"]/Baseline ,col = "blue",pch=9)
	points(plotSlopCO2_exp$time/60,(plotSlopCO2_exp$slope_50+100)/100,col= "green", pch=9)
	dev.off()
	
}