#!/bin/sh
#$ -cwd
#$ -pe thread 8
#$ -j y
#$ -P CDERID0047
#$ -N Simulateiman
#$ -l s_rt=24:00:00
#$ -R y
#$ -l h_vmem=8G
#$ -l h_rt=24:00:00
#$ -t 1
#$ -o NULL






Rscript simulate_Overdose_Rmodel.R >& logfiles/"$JOB_NAME".o"$JOB_ID"."$SGE_TASK_ID".txt

